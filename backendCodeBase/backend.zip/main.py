
import urllib
import os
import sys
import json


def lambda_handler(event, context):

    return {
        'statusCode': 200,
        'body': "yas"
    }